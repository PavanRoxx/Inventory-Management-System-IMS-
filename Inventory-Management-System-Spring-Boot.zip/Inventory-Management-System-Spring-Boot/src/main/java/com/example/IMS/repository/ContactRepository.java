package com.example.IMS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.IMS.model.Contact;

public interface ContactRepository extends JpaRepository<Contact, Long> {
    // Add custom queries if needed
}

