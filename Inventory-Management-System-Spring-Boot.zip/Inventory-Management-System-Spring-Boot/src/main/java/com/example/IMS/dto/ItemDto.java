package com.example.IMS.dto;

public class ItemDto {

    private long itemId;
    private int itemQuantity;
    private long user_id;
    private long invoiceNumber;
    private double itemPrice;
    private double fineRate;
    private String itemName;
    private String itemType;
    private String vendorName;

    public ItemDto() {
    }

    public ItemDto(long itemId, int itemQuantity, long user_id, long invoiceNumber, double itemPrice, double fineRate,
            String itemName, String itemType, String vendorName) {
        this.itemId = itemId;
        this.itemQuantity = itemQuantity;
        this.user_id = user_id;
        this.invoiceNumber = invoiceNumber;
        this.itemPrice = itemPrice;
        this.fineRate = fineRate;
        this.itemName = itemName;
        this.itemType = itemType;
        this.vendorName = vendorName;
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public long getUser_id() {
        return user_id;
    }

    public void setUser_id(long user_id) {
        this.user_id = user_id;
    }

    public long getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(long invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public double getFineRate() {
        return fineRate;
    }

    public void setFineRate(double fineRate) {
        this.fineRate = fineRate;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }
}
