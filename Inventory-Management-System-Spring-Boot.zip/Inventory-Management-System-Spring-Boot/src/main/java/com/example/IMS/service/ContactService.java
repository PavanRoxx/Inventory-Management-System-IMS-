package com.example.IMS.service;

import com.example.IMS.model.Contact;

public interface ContactService {
    void saveContact(Contact contact);
}
