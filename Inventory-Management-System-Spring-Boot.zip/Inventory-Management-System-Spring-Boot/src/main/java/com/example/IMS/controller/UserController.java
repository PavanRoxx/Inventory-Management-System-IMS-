package com.example.IMS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.example.IMS.service.UserService;

import com.example.IMS.model.User;

import javax.validation.Valid;
import java.util.List;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping("/viewuser")
	public String showUsers(Model model) {
		List<User> userList = userService.getAllUsers();
		model.addAttribute("userList", userList);
		return "admin/viewuser";
	}

	@GetMapping("/edituser/{id}")
	public String editUser(@PathVariable Long id, Model model) {
		// Retrieve the user by ID from the database
		User user = userService.getUserById(id);

		// Add the user to the model so it can be accessed in Thymeleaf template
		model.addAttribute("user", user);

		// Return the name of the Thymeleaf template (edituser.html)
		return "admin/edituser";
	}

	/*
	 * @PostMapping("/edituser/{id}") public String updateUser(@PathVariable("id")
	 * Long id, @ModelAttribute("user") User user) { // Validate and update user in
	 * the database using UserService userService.editUser(id, user); return
	 * "redirect:/viewuser"; // Redirect to the user list page }
	 */
	
	@PostMapping("/edituser/{id}")
	public String updateUser(@PathVariable("id") Long id, @ModelAttribute("user") User user, BindingResult bindingResult) {
	    if (bindingResult.hasErrors()) {
	        // Log or print validation errors
	        System.out.println("Validation errors: " + bindingResult.getAllErrors());
	        return "admin/edituser"; // Return to the edituser page
	    }
	    userService.editUser(id, user);
	    return "redirect:/viewuser"; // Redirect to the user list page
	}


	/*
	 * @GetMapping("/viewuser") public String showAddUserForm(Model model) {
	 * model.addAttribute("user", new com.example.IMS.model.User()); return
	 * "admin/viewuser"; }
	 * 
	 * @PostMapping("/viewuser") public String
	 * addUser(@ModelAttribute("user") @Valid com.example.IMS.model.User user,
	 * BindingResult bindingResult) { if (bindingResult.hasErrors()) { return
	 * "admin/viewuser"; } userService.saveUser(user); return "redirect:/users"; }
	 */

	/*
	 * @GetMapping("/edituser/{id}") public String showEditUserForm(@PathVariable
	 * Long id, Model model) { com.example.IMS.model.User user =
	 * userService.getUserById(id); model.addAttribute("user", user); return
	 * "edituser"; }
	 */

	/*
	 * @PostMapping("/edituser/{id}") public String editUser(@PathVariable Long
	 * id, @ModelAttribute("user") @Valid com.example.IMS.model.User user,
	 * BindingResult bindingResult) { if (bindingResult.hasErrors()) { return
	 * "edituser"; } userService.editUser(id, user); return "redirect:/users"; }
	 */
	@GetMapping("/deleteuser/{id}")
	public String deleteUser(@PathVariable Long id) {
		userService.deleteUser(id);
		return "admin/deleteuser";
	}

	@GetMapping("/UserDetails/{id}")
	public String viewUserDetails(@PathVariable Long id, Model model) {
		com.example.IMS.model.User user = userService.getUserById(id);
		model.addAttribute("user", user);
		return "userDetails";
	}
}
