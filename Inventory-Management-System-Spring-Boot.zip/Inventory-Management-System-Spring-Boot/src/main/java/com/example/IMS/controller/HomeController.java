package com.example.IMS.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.IMS.model.User;
import com.example.IMS.service.UserService;
@Controller
public class HomeController {

    private final UserService userService;

    @Autowired
    public HomeController(UserService userService) {
        this.userService = userService;
    }
	 @GetMapping("/")
	    public String login(){
	        return "login";
	    }
	 
	 @GetMapping("/index2")
	    public String Index2(){
	        return "index2";
	    }
	 @GetMapping("/index")
	    public String Index(){
	        return "index";
	    }
	 
	   @GetMapping("/adduser")
	    public String showAddUserForm(Model model) {
	        model.addAttribute("user", new User());
	        return "admin/adduser";
	    }

	   @PostMapping("/adduser")
	   public String addUser(@ModelAttribute("user") @Valid User user, BindingResult bindingResult) {
	       if (bindingResult.hasErrors()) {
	           return "admin/adduser";
	       }

	       // Save the user to the database (Assuming you have a UserService)
	       userService.saveUser(user);

	       // Redirect to the user list page or another appropriate page
	       return "redirect:/adduser";
	   }
}
