package com.example.IMS.service;

import java.util.List;

import com.example.IMS.model.User;

public interface UserService {
    User authenticateUser(String email, String password);

    // Remove 'static' keyword
    void saveUser(User user);

    void registerUser(User user);
    void addUser(User user);
    void editUser(Long id, User user);
    void deleteUser(Long id);
    User getUserById(Long id);
    List<User> getAllUsers();
}
